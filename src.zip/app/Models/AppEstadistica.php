<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class AppEstadistica extends Model
{

    protected $table = 'app_estadisticas';

}
